// echo.js

return function(args) {
    if (!args) {
        return "";
    }
    return args;
};
